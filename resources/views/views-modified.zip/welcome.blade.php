<html lang="{{ str_replace('_', '-', app()->getLocale()) }}">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Pawmilya</title>
    @vite(['public\build\assets\app-B48Gl7uk.js', 'public\build\assets\app-CksuuEqD.css', 'public\build\assets\app-ppxbJnil.css'])
</head>

<body>
    <h1>Welcome</h1>
</body>

</html>
